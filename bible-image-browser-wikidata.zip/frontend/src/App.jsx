import React, { useEffect, useState } from 'react';

export default function App() {
  const [images, setImages] = useState([]);

  const query = `
    SELECT ?item ?itemLabel ?description ?image WHERE {
      ?item wdt:P31 wd:Q3305213.  # instance of map
      OPTIONAL { ?item schema:description ?description FILTER (lang(?description) = "en") }
      OPTIONAL { ?item wdt:P18 ?image }
      SERVICE wikibase:label { bd:serviceParam wikibase:language "en". }
    }
    LIMIT 20
  `;

  useEffect(() => {
    fetch('https://query.wikidata.org/sparql?query=' + encodeURIComponent(query), {
      headers: { Accept: 'application/sparql-results+json' },
    })
      .then(res => res.json())
      .then(data => {
        const results = data.results.bindings.map((entry) => ({
          title: entry.itemLabel?.value,
          description: entry.description?.value,
          image: entry.image?.value,
        }));
        setImages(results);
      });
  }, []);

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-6">Bible Image Browser (Wikidata)</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {images.map((img, i) => (
          <div key={i} className="border rounded shadow p-4 bg-white">
            {img.image && (
              <img src={img.image} alt={img.title} className="w-full h-48 object-cover mb-2" />
            )}
            <h2 className="text-lg font-semibold">{img.title}</h2>
            <p className="text-sm text-gray-700">{img.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
