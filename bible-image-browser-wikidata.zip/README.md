# Bible Image Browser (Wikidata Version)

Install and run:
```bash
npm install
npm run dev
```